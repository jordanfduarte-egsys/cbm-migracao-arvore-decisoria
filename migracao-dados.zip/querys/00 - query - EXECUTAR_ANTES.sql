

-- INGLES



-- SQL INSERT AGENCIA ENVOLVIDA: INGLES <--- (EXECUTAR ANTES DE TUDO)

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('ABS', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('ABTR', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('AA', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('SAV', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AERONAVE') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('AERONAVE', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PGV') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('PGV', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OER') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('OER', 3);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('ALFANUMÉRICO') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('ALFANUMÉRICO', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('INT') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('INT', 1);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('COPEL') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('COPEL', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAMU') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('SAMU', 3);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('RCP adulto') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('RCP adulto', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('criança') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('criança', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('bebê') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('bebê', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Informar que está deslocando socorro somente para confirmação do óbito.') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('Informar que está deslocando socorro somente para confirmação do óbito.', 1);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PM') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('PM', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Resgate') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Resgate', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('SBV', 3);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Verifique se a vítima traz algum medicamento consigo') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('Verifique se a vítima traz algum medicamento consigo', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Aguardar apoio de Viatura Policial') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('Aguardar apoio de Viatura Policial', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Aguardar apoio Policial') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('Aguardar apoio Policial', 1);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OF.ÁREA') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('OF.ÁREA', 3);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('(Espaço Confinado) Não adentre na área sob') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('(Espaço Confinado) Não adentre na área sob', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('risco de tornar') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('risco de tornar', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('se vítima. B20') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('se vítima. B20', 1);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('TRÂNSITO') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('TRÂNSITO', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PRF') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('PRF', 3);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('PRE') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('PRE', 1);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Polícia de Trânsito') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Polícia de Trânsito', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Trânsito') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Trânsito', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('A critério do Despachante') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('A critério do Despachante', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('CONCESSIONÁRIA') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('CONCESSIONÁRIA', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Órgão de Trânsito') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Órgão de Trânsito', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AHQ') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('AHQ', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AQ') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('AQ', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('GM') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('GM', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Concessionária') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Concessionária', 3);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Prefeitura') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('Prefeitura', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Força Verde') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('Força Verde', 1);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('ONGS') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('ONGS', 1);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Oficial') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Oficial', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Médico') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Médico', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Copel') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Copel', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OFICIAL') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('OFICIAL', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABRT') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('ABRT', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ANTIBOMBA') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('ANTIBOMBA', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('MÉDICO') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('MÉDICO', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AT') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('AT', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABT') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('ABT', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AEM') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('AEM', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AP') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('AP', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PMPR') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('PMPR', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTF') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('ABTF', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Polícia Militar') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Polícia Militar', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Aeronautica') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Aeronautica', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('BRIGADA AEROPORTO') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('BRIGADA AEROPORTO', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Marinha') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Marinha', 3);

SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('ARQUIVO .JPG OU .PNG') AND cbm_tipo_apoio_externo.excluido = 0 LIMIT 1

INSERT INTO cbm_tipo_apoio_externo (descricao, envia_para_mobile) VALUES('ARQUIVO .JPG OU .PNG', 1);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('MAS') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('MAS', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('BIS') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('BIS', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Polícia Civil') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('Polícia Civil', 3);

SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SA') AND (tipo_guarnicao.excluido = 0 OR tipo_guarnicao.descricao = 'A Critério do Despachante') LIMIT 1

INSERT INTO tipo_guarnicao (descricao, id_agencia) VALUES('SA', 3);
