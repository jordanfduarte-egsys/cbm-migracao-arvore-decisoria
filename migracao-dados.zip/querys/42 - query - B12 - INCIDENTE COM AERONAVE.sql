--SQL CLASSIFICACAO -- ATENÇÃO VER SE JA NAO EXISTE (EXECUTAR ANTES DE TD DESSA NATUREZA)<--------------

SELECT * FROM classificacao_atendimento WHERE descricao = 'B12 - INCIDENTE COM AERONAVE' AND classificacao_atendimento.excluido = 0 ;
INSERT INTO public.classificacao_atendimento (descricao, id_tipo_atendimento, id_nivel_atendimento, id_categoria) VALUES('B12 - INCIDENTE COM AERONAVE', 354, 3, 24);

                INSERT INTO public.classificacao_atend_agencia (id_classificacao_atendimento, id_agencia) VALUES ((SELECT classificacao_atendimento1.id FROM classificacao_atendimento classificacao_atendimento1 WHERE classificacao_atendimento1.descricao = 'B12 - INCIDENTE COM AERONAVE' AND classificacao_atendimento1.id_nivel_atendimento = 3  AND classificacao_atendimento1.excluido = 0), 3);


-- SQL CARD

INSERT INTO arv_card (id_classificacao_atendimento, descricao) VALUES (
                (SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE descricao = 'B12 - INCIDENTE COM AERONAVE'  AND classificacao_atendimento.excluido = 0 LIMIT 1),
                'B12 - INCIDENTE COM AERONAVE'
            );


-- SQL de PERGUNTAS

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Fonte de Acionamento?', 0, 1);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Que tipo de aeronave?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual o tipo de incidente com aeronave?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual o motivo do Alerta?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A aeronave já pousou ou irá realizar o pouso?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual o local do pouso?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual a cia área, número do voo, matrícula da aeronave, saída e destino? ', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Quantas pessoas estão a bordo (POB)?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'É uma aeronave de Carga? Qual a Carga', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Onde foi a queda?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Existem sobreviventes?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Existem vítimas decorrentes da queda?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Existem incêndio ou risco de incêndio', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual a intenção do sequestrador?', 0, 0);


-- SQL de ALTERNATIVAS

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Fonte de Acionamento?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Que tipo de aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Torre de controle', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Fonte de Acionamento?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Que tipo de aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outros', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Que tipo de aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Asa Fixa', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Que tipo de aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Asa Rotativa', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Que tipo de aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outros', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual o motivo do Alerta?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Alerta', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A aeronave já pousou ou irá realizar o pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Pouso forçado', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Onde foi a queda?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Queda', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a intenção do sequestrador?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sequestro', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o motivo do Alerta?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A aeronave já pousou ou irá realizar o pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Falha de Motor', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o motivo do Alerta?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A aeronave já pousou ou irá realizar o pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Falha de Trem de Pouso', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o motivo do Alerta?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A aeronave já pousou ou irá realizar o pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Despressurização', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o motivo do Alerta?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A aeronave já pousou ou irá realizar o pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Passageiro em risco', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o motivo do Alerta?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A aeronave já pousou ou irá realizar o pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outros/Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A aeronave já pousou ou irá realizar o pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual o local do pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Pousou', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A aeronave já pousou ou irá realizar o pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual o local do pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Irá pousar', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o local do pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a cia área, número do voo, matrícula da aeronave, saída e destino? ' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Aeroporto/Qual?', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o local do pouso?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a cia área, número do voo, matrícula da aeronave, saída e destino? ' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outro Local/Qual?', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a cia área, número do voo, matrícula da aeronave, saída e destino? ' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quantas pessoas estão a bordo (POB)?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quantas pessoas estão a bordo (POB)?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É uma aeronave de Carga? Qual a Carga' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'É uma aeronave de Carga? Qual a Carga' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Sim/Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'É uma aeronave de Carga? Qual a Carga' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Onde foi a queda?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existem sobreviventes?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existem sobreviventes?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existem vítimas decorrentes da queda?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sim/Descrever', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existem sobreviventes?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existem vítimas decorrentes da queda?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existem sobreviventes?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existem vítimas decorrentes da queda?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não é possível avaliar', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existem vítimas decorrentes da queda?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sim/descrever', 1, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existem vítimas decorrentes da queda?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Sim/descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a intenção do sequestrador?' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a cia área, número do voo, matrícula da aeronave, saída e destino? ' AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));


-- SQL de AGE. ENVOLVIDO

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Aeronautica') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Alerta' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Aeronautica') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Pouso forçado' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Pouso forçado' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Pouso forçado' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAMU') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Pouso forçado' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Aeronautica') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Queda' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Queda' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Queda' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAMU') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Queda' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Aeronautica') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sequestro' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de incidente com aeronave?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('BRIGADA AEROPORTO') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Aeroporto/Qual?' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o local do pouso?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Outro Local/Qual?' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o local do pouso?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Outro Local/Qual?' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o local do pouso?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim/Descrever' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existem sobreviventes?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim/Descrever' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existem sobreviventes?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim/descrever' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existem vítimas decorrentes da queda?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim/descrever' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existem vítimas decorrentes da queda?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );


-- SQL ORIENTACOES NATUREZA

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 LIMIT 1),
                        '(Incêndio) Afaste as pessoas do local.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 LIMIT 1),
                        '(Pessoa em chama) Peça para que ela pare deite e role no chão cobrindo a face com as mãos, jogue água na vítima e/ou abafe o fogo com um cobertor, toalha ou uma jaqueta.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 LIMIT 1),
                        'Não mexa em nada na cena para posterior perícia do acidente.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 LIMIT 1),
                        'Isole o local e não deixe que ninguém se aproxime.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 LIMIT 1),
                        'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.'
                    );


-- SQL ALTERNATIVA ORIENTACAO

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Incêndio) Afaste as pessoas do local.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Pessoa em chama) Peça para que ela pare deite e role no chão cobrindo a face com as mãos, jogue água na vítima e/ou abafe o fogo com um cobertor, toalha ou uma jaqueta.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Não mexa em nada na cena para posterior perícia do acidente.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Isole o local e não deixe que ninguém se aproxime.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );


-- SQL INSERT ORIENTACOES DA NATUREZA NOVA TABELA <--- (EXECUTAR DEPOIS DE TODAS AS QUERYS DESSA NATUREZA)

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'É uma aeronave de Carga? Qual a Carga' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim/Descrever' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'É uma aeronave de Carga? Qual a Carga' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim/descrever' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Incêndio) Afaste as pessoas do local.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim/descrever' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Pessoa em chama) Peça para que ela pare deite e role no chão cobrindo a face com as mãos, jogue água na vítima e/ou abafe o fogo com um cobertor, toalha ou uma jaqueta.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim/descrever' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não mexa em nada na cena para posterior perícia do acidente.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim/descrever' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Isole o local e não deixe que ninguém se aproxime.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            3
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim/descrever' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            4
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não mexa em nada na cena para posterior perícia do acidente.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Isole o local e não deixe que ninguém se aproxime.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existem incêndio ou risco de incêndio' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B12 - INCIDENTE COM AERONAVE') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B12 - INCIDENTE COM AERONAVE' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );


-- SQL UPDATE ALTERNATIVAS DAS ORIENTAÇÔES DESSA NATUREZA QUE CHAMA OUTRA ORIENTAÇÃO DESSA NATUREZA TMB

