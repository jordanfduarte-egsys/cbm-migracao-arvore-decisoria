--SQL CLASSIFICACAO -- ATENÇÃO VER SE JA NAO EXISTE (EXECUTAR ANTES DE TD DESSA NATUREZA)<--------------

SELECT * FROM classificacao_atendimento WHERE descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND classificacao_atendimento.excluido = 0 ;
INSERT INTO public.classificacao_atendimento (descricao, id_tipo_atendimento, id_nivel_atendimento, id_categoria) VALUES('C14 - SUICÍDIO - TENTATIVA DE S', 352, 3, 24);

                INSERT INTO public.classificacao_atend_agencia (id_classificacao_atendimento, id_agencia) VALUES ((SELECT classificacao_atendimento1.id FROM classificacao_atendimento classificacao_atendimento1 WHERE classificacao_atendimento1.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND classificacao_atendimento1.id_nivel_atendimento = 3  AND classificacao_atendimento1.excluido = 0), 3);


-- SQL CARD

INSERT INTO arv_card (id_classificacao_atendimento, descricao) VALUES (
                (SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE descricao = 'C14 - SUICÍDIO - TENTATIVA DE S'  AND classificacao_atendimento.excluido = 0 LIMIT 1),
                'C14 - SUICÍDIO - TENTATIVA DE S'
            );


-- SQL de PERGUNTAS

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Solicitante é a própria vítima ligando para relatar a intenção de suicídio.', 0, 1);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Está tentando suicídio? Ou já cometeu o suicídio?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Você está próximo o suficiente para conversar com a vítima, sem colocar-se em risco?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual o meio usado para tentar ou cometer o suicídio?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A vítima está alerta?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A pessoa respira normalmente?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Observe e descreva a respiração ', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Possui alguma lesão/hemorragia grave?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A pessoa está violenta?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A pessoa possui algum tipo de arma?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Existe outro Risco? Queda, fogo, etc?', 0, 0);


-- SQL de ALTERNATIVAS

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Solicitante é a própria vítima ligando para relatar a intenção de suicídio.' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Solicitante é a própria vítima ligando para relatar a intenção de suicídio.' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Está tentando suicídio? Ou já cometeu o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Está tentando suicídio? Ou já cometeu o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Você está próximo o suficiente para conversar com a vítima, sem colocar-se em risco?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Tentando', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Está tentando suicídio? Ou já cometeu o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Você está próximo o suficiente para conversar com a vítima, sem colocar-se em risco?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Já cometeu', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Está tentando suicídio? Ou já cometeu o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Você está próximo o suficiente para conversar com a vítima, sem colocar-se em risco?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Você está próximo o suficiente para conversar com a vítima, sem colocar-se em risco?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Você está próximo o suficiente para conversar com a vítima, sem colocar-se em risco?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa está violenta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Arma de fogo', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Arma branca', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Queda', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A vítima está alerta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Enforcamento', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 2, 'Medicamentos', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Fogo', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A vítima está alerta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Outro - Descrever', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima está alerta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima está alerta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima está alerta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Possui alguma lesão/hemorragia grave?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Não respira', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Ausência de movimentos no tórax', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Respiração Agônica (gasping)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Possui alguma lesão/hemorragia grave?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Pausa respiratória (apneia)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Possui alguma lesão/hemorragia grave?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Respiração ruidosa', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Possui alguma lesão/hemorragia grave?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Falta de ar', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Possui alguma lesão/hemorragia grave?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Respiração pouco ruidosa', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Possui alguma lesão/hemorragia grave?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa está violenta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Possui alguma lesão/hemorragia grave?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa está violenta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Possui alguma lesão/hemorragia grave?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa está violenta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa está violenta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Sim', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa está violenta?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sim. Arma de fogo', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sim. Arma branca', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Sim. Arma contundente', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não Sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Sim. Queda', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Sim. Fogo', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Sim. Afogamento', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Sim. Outro. Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Não Sabe', 0, 0, 0, NULL);


-- SQL de AGE. ENVOLVIDO

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OF.ÁREA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa está violenta?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa está violenta?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa está violenta?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PM') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa está violenta?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OF.ÁREA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma de fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma de fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma de fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PM') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma de fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OF.ÁREA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma branca' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma branca' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma branca' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PM') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma branca' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OF.ÁREA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma contundente' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma contundente' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma contundente' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PM') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Arma contundente' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OF.ÁREA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Queda' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Queda' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Queda' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PM') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Queda' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OF.ÁREA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PM') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('OF.ÁREA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Afogamento' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Afogamento' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Afogamento' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('PM') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim. Afogamento' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Existe outro Risco? Queda, fogo, etc?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );


-- SQL ORIENTACOES NATUREZA

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 LIMIT 1),
                        '(Vítima não alerta) VÁ PARA O CARTÃO DE RCP'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 LIMIT 1),
                        '(Solicitante é o tentante) Siga procedimentos de persuassão do suicídio.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 LIMIT 1),
                        '(Enforcamento) Corte a corda'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 LIMIT 1),
                        '(Arma) Chame a polícia para garantir a segurança da cena'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 LIMIT 1),
                        'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.'
                    );


-- SQL ALTERNATIVA ORIENTACAO

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Vítima não alerta) VÁ PARA O CARTÃO DE RCP' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Solicitante é o tentante) Siga procedimentos de persuassão do suicídio.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Enforcamento) Corte a corda' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Arma) Chame a polícia para garantir a segurança da cena' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );


-- SQL INSERT ORIENTACOES DA NATUREZA NOVA TABELA <--- (EXECUTAR DEPOIS DE TODAS AS QUERYS DESSA NATUREZA)

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Solicitante é a própria vítima ligando para relatar a intenção de suicídio.' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Solicitante é o tentante) Siga procedimentos de persuassão do suicídio.' AND arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, id_outra_arv_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Arma de fogo' AND arv_perg_alt.excluido = 0
                        
                        ),
                        415, -- padrão
                        (
                            select arv_perg1.id from arv_perg arv_perg1
                            inner join classificacao_atendimento classificacao_atendimento1 on
                                classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                            where classificacao_atendimento1.descricao like 'T4%' and arv_perg1.excluido  = 0 
                            limit 1 offset 0
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, id_outra_arv_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Arma branca' AND arv_perg_alt.excluido = 0
                        
                        ),
                        415, -- padrão
                        (
                            select arv_perg1.id from arv_perg arv_perg1
                            inner join classificacao_atendimento classificacao_atendimento1 on
                                classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                            where classificacao_atendimento1.descricao like 'T4%' and arv_perg1.excluido  = 0 
                            limit 1 offset 0
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, id_outra_arv_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Queda' AND arv_perg_alt.excluido = 0
                        
                        ),
                        415, -- padrão
                        (
                            select arv_perg1.id from arv_perg arv_perg1
                            inner join classificacao_atendimento classificacao_atendimento1 on
                                classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                            where classificacao_atendimento1.descricao like 'T7%' and arv_perg1.excluido  = 0 
                            limit 1 offset 0
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Enforcamento' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Solicitante é o tentante) Siga procedimentos de persuassão do suicídio.' AND arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, id_outra_arv_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Medicamentos' AND arv_perg_alt.excluido = 0
                        
                        ),
                        415, -- padrão
                        (
                            select arv_perg1.id from arv_perg arv_perg1
                            inner join classificacao_atendimento classificacao_atendimento1 on
                                classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                            where classificacao_atendimento1.descricao like 'C9%' and arv_perg1.excluido  = 0 
                            limit 1 offset 0
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, id_outra_arv_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o meio usado para tentar ou cometer o suicídio?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Fogo' AND arv_perg_alt.excluido = 0
                        
                        ),
                        415, -- padrão
                        (
                            select arv_perg1.id from arv_perg arv_perg1
                            inner join classificacao_atendimento classificacao_atendimento1 on
                                classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                            where classificacao_atendimento1.descricao like 'T8%' and arv_perg1.excluido  = 0 
                            limit 1 offset 0
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa respira normalmente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Não respira' AND arv_perg_alt.excluido = 0
                        
                        ),
                        (
                            SELECT arv_card_perg.id FROM arv_card_perg 
                        INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                        WHERE UPPER(arv_card.descricao) = UPPER('RCP') and arv_card_perg.is_pergunta_raiz = 1 and arv_card_perg.excluido = 0 limit 1
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Ausência de movimentos no tórax' AND arv_perg_alt.excluido = 0
                        
                        ),
                        (
                            SELECT arv_card_perg.id FROM arv_card_perg 
                        INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                        WHERE UPPER(arv_card.descricao) = UPPER('RCP') and arv_card_perg.is_pergunta_raiz = 1 and arv_card_perg.excluido = 0 limit 1
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Respiração Agônica (gasping)' AND arv_perg_alt.excluido = 0
                        
                        ),
                        (
                            SELECT arv_card_perg.id FROM arv_card_perg 
                        INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                        WHERE UPPER(arv_card.descricao) = UPPER('RCP') and arv_card_perg.is_pergunta_raiz = 1 and arv_card_perg.excluido = 0 limit 1
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa está violenta?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Arma) Chame a polícia para garantir a segurança da cena' AND arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim. Arma de fogo' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Arma) Chame a polícia para garantir a segurança da cena' AND arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim. Arma branca' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Arma) Chame a polícia para garantir a segurança da cena' AND arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa possui algum tipo de arma?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C14 - SUICÍDIO - TENTATIVA DE S') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim. Arma contundente' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Arma) Chame a polícia para garantir a segurança da cena' AND arv_card.descricao = 'C14 - SUICÍDIO - TENTATIVA DE S' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );


-- SQL UPDATE ALTERNATIVAS DAS ORIENTAÇÔES DESSA NATUREZA QUE CHAMA OUTRA ORIENTAÇÃO DESSA NATUREZA TMB

