--SQL CLASSIFICACAO -- ATENÇÃO VER SE JA NAO EXISTE (EXECUTAR ANTES DE TD DESSA NATUREZA)<--------------

SELECT * FROM classificacao_atendimento WHERE descricao = 'B16 - PESSOA PERDIDA' AND classificacao_atendimento.excluido = 0 ;
INSERT INTO public.classificacao_atendimento (descricao, id_tipo_atendimento, id_nivel_atendimento, id_categoria) VALUES('B16 - PESSOA PERDIDA', 354, 3, 24);

                INSERT INTO public.classificacao_atend_agencia (id_classificacao_atendimento, id_agencia) VALUES ((SELECT classificacao_atendimento1.id FROM classificacao_atendimento classificacao_atendimento1 WHERE classificacao_atendimento1.descricao = 'B16 - PESSOA PERDIDA' AND classificacao_atendimento1.id_nivel_atendimento = 3  AND classificacao_atendimento1.excluido = 0), 3);


-- SQL CARD

INSERT INTO arv_card (id_classificacao_atendimento, descricao) VALUES (
                (SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE descricao = 'B16 - PESSOA PERDIDA'  AND classificacao_atendimento.excluido = 0 LIMIT 1),
                'B16 - PESSOA PERDIDA'
            );


-- SQL de PERGUNTAS

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A vítima é o próprio solicitante ou está junto à vítima?', 0, 1);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Você está ligando de aparelho celular? ', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), '(Vítima próprio solicitante)
Quanto possui de bateria?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Quantas pessoas estão perdidas?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Você/Alguém está ferido?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A vítima está consciente?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual(is) o(s) nome(s) da(s) pessoa(s)?
(Vítima próprio solicitante) Qual seu nome?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Quai(s) Idade(s)?
Uma pessoa/+1 pessoa', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Quai(s) Sexo(s)?
Uma pessoa/+1 pessoa', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A vítima é portadora de necessidade especial?
Tem algum problema médico?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), '(Vítima próprio solicitante/junto da vítima)
Como está o tempo (clima) onde você está? (bom, chuvoso, frio)', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Esse comportamento de sumir já ocorreu outras vezes?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Foi verificado os locais de frequencia comum? (residência, casa de parentes e amigos, locais de esporte e lazer, etc)? Hospitais, Unidades de Pronto Atendimento, Unidades Básicas de Saúde?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Foi obtida alguma informação nestes contatos?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Vestimentas? (Cores, inscrições, tipo)?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Quais as características físicas? ', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Há quanto tempo está perdida?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual o último local em que foi visto(a)?
Você consegue me mandar a localização (Whatsapp ou outro aplicativo)?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A pessoa conhece o local?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), '(Vítima próprio solicitante/junto da vítima)
Você/Alguém presente conhece o local?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?', 0, 0);


-- SQL de ALTERNATIVAS

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é o próprio solicitante ou está junto à vítima?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Você está ligando de aparelho celular? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é o próprio solicitante ou está junto à vítima?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quantas pessoas estão perdidas?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Você está ligando de aparelho celular? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante)
Quanto possui de bateria?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Você está ligando de aparelho celular? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quantas pessoas estão perdidas?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante)
Quanto possui de bateria?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quantas pessoas estão perdidas?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Numérico', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante)
Quanto possui de bateria?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quantas pessoas estão perdidas?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, '', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quantas pessoas estão perdidas?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Você/Alguém está ferido?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Numérico', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Você/Alguém está ferido?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A vítima está consciente?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sim (descrever)', 1, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Você/Alguém está ferido?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A vítima está consciente?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima está consciente?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual(is) o(s) nome(s) da(s) pessoa(s)?
(Vítima próprio solicitante) Qual seu nome?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima está consciente?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual(is) o(s) nome(s) da(s) pessoa(s)?
(Vítima próprio solicitante) Qual seu nome?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Não', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual(is) o(s) nome(s) da(s) pessoa(s)?
(Vítima próprio solicitante) Qual seu nome?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quai(s) Idade(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quai(s) Idade(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quai(s) Sexo(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Numérico', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'INT' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quai(s) Idade(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quai(s) Sexo(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança (até 12 anos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quai(s) Idade(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quai(s) Sexo(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Idoso (acima de 60 anos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quai(s) Idade(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quai(s) Sexo(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quai(s) Sexo(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Feminino', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quai(s) Sexo(s)?
Uma pessoa/+1 pessoa' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Masculino', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não/Nenhum', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Autista', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança (1-3 anos)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança (4-6 anos)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança (7-9 anos)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança/Pré-Adoslecente
(10-12 anos)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Adolescente (13-15 anos)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Pessoa com Deficiência (PcD)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Idoso (acima de 60 anos)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Alzheimer
(Qual estágio?)
Leve/Moderado/Avançado', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Demência', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Depressão', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Grávida', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'MULTIPLE' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outro/Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não/Nenhum', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Autista', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança (1-3 anos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança (4-6 anos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança (7-9 anos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Criança/Pré-Adoslecente
(10-12 anos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Adolescente (13-15 anos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Pessoa com Deficiência (PcD)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Idoso (acima de 60 anos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Alzheimer
(Qual estágio?)
Leve/Moderado/Avançado', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Demência', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Depressão', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Grávida', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A vítima é portadora de necessidade especial?
Tem algum problema médico?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Outro/Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Como está o tempo (clima) onde você está? (bom, chuvoso, frio)' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Vestimentas? (Cores, inscrições, tipo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Bom', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Como está o tempo (clima) onde você está? (bom, chuvoso, frio)' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Vestimentas? (Cores, inscrições, tipo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Ruim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Foi verificado os locais de frequencia comum? (residência, casa de parentes e amigos, locais de esporte e lazer, etc)? Hospitais, Unidades de Pronto Atendimento, Unidades Básicas de Saúde?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim (Quantas?)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'INT' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Esse comportamento de sumir já ocorreu outras vezes?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Foi verificado os locais de frequencia comum? (residência, casa de parentes e amigos, locais de esporte e lazer, etc)? Hospitais, Unidades de Pronto Atendimento, Unidades Básicas de Saúde?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Foi verificado os locais de frequencia comum? (residência, casa de parentes e amigos, locais de esporte e lazer, etc)? Hospitais, Unidades de Pronto Atendimento, Unidades Básicas de Saúde?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Foi obtida alguma informação nestes contatos?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim (Quais?)

Solicitar contatos e registrar (Nome, Parentesco/Função, Telefone e Endereço)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Foi verificado os locais de frequencia comum? (residência, casa de parentes e amigos, locais de esporte e lazer, etc)? Hospitais, Unidades de Pronto Atendimento, Unidades Básicas de Saúde?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Foi obtida alguma informação nestes contatos?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Vestimentas? (Cores, inscrições, tipo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim (Quais?)/Descrever
Quem passou essa informação?
(Nome/Parentesco ou Função/Contato)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Foi obtida alguma informação nestes contatos?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Vestimentas? (Cores, inscrições, tipo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Vestimentas? (Cores, inscrições, tipo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quais as características físicas? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Vestimentas? (Cores, inscrições, tipo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Descrever', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quais as características físicas? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Altura', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quais as características físicas? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Peso', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quais as características físicas? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Cor da Pele', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quais as características físicas? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Cor/Tipo do cabelo', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quais as características físicas? ' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Foto da Vítima (recente)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Até 48h', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, '', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, '', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Acima de 48h', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, '', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, '', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Há quanto tempo está perdida?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Numérico (horas)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'INT' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Sim

Solicitar contatos e registrar (Nome, Parentesco, Telefone e Endereço)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual o último local em que foi visto(a)?
Você consegue me mandar a localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o último local em que foi visto(a)?
Você consegue me mandar a localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Descrever
(inserir ponto e/ou coordenadas)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o último local em que foi visto(a)?
Você consegue me mandar a localização (Whatsapp ou outro aplicativo)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim (Quais?)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Não', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Sim (Quais?)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Descrever
(inserir ponto e/ou coordenadas)', 1, 1, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Urbano', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Rural', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Mata/Trilha', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Montanha', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Rio/Lago', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Mar/Oceano', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe/Não se aplica', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outro (descrever)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 1, 'Sim', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 2, 'Não', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não se aplica', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/Alguém presente conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Sim', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/Alguém presente conhece o local?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 1, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Não', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);


-- SQL de AGE. ENVOLVIDO

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim (descrever)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Você/Alguém está ferido?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('AA') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A vítima está consciente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A vítima está consciente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A vítima está consciente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('ARQUIVO .JPG OU .PNG') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Foto da Vítima (recente)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Quais as características físicas? ' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim

Solicitar contatos e registrar (Nome, Parentesco, Telefone e Endereço)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Possui recursos (água, alimentos, abrigo, muda de roupa, materiais de sobrevivência)?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Descrever
(inserir ponto e/ou coordenadas)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Mata/Trilha' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Montanha' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Rio/Lago' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('MAS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Mar/Oceano' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('BIS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Mar/Oceano' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa conhece o local?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('Polícia Civil') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );


-- SQL ORIENTACOES NATUREZA

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 LIMIT 1),
                        '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 LIMIT 1),
                        'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 LIMIT 1),
                        'Por favor, realize contato com parentes, amigos e nos locais de frequência comum para ter certeza que esta pessoa está perdida e deseja ser encontrada. Oriente a buscar vestígios sobre o desaparecimento. Notas, planos, recibos, contatos com amigos.       '
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 LIMIT 1),
                        'Essa situação não se enquadra no atendimento no Corpo de Bombeiros, por se tratar de pessoa desaparecida, e não de pessoa perdida. Por favor, solicite atendimento da Polícia Civil através da abertura de Boletim de Ocorrência'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 LIMIT 1),
                        'Essa situação não se enquadra no atendimento no Corpo de Bombeiros, por favor aguarde informações da Polícia Civil ou entre em contato com órgào responsável ou quem de direito'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 LIMIT 1),
                        'Ative a economia de bateria e feche aplicativos secundários. Por favor me passe contatos e nomes das pessoas que estão com você (com DDD) para podermos entrar em contato caso sua bateria acabe. Fique atento ao recebimento de ligações e de mensagens via aplicativo e SMS'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 LIMIT 1),
                        'Orientar a enviar coordenadas:

Ponha no Viva Voz e abra o aplicativo do Google Maps (mesmo sem sinal de internet) O círculo azul indicará sua posição. 

Clique e segure sobre este ponto até que um alfinete vermelho seja inserido, a barra superior mostrará uma sequência de números. 

Essas são as coordenadas de onde você está. Repasse exatamente como você vê.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 LIMIT 1),
                        '"Pare, sente-se confortavelmente, como algo, beba água e então procure se reorientar. Escute minhas orientações e tente segui-las."

Se você conhece suficientemente o local (ou possui registros como tracklogs, etc). 

Uma vez que a vítima esteja apenas DESORIENTADA, procure orientá-la de maneira que ela retorne para um ponto conhecido e se reoriente, tornando a ficar em segurança.'
                    );


-- SQL ALTERNATIVA ORIENTACAO

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Por favor, realize contato com parentes, amigos e nos locais de frequência comum para ter certeza que esta pessoa está perdida e deseja ser encontrada. Oriente a buscar vestígios sobre o desaparecimento. Notas, planos, recibos, contatos com amigos.       ' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Essa situação não se enquadra no atendimento no Corpo de Bombeiros, por se tratar de pessoa desaparecida, e não de pessoa perdida. Por favor, solicite atendimento da Polícia Civil através da abertura de Boletim de Ocorrência' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Essa situação não se enquadra no atendimento no Corpo de Bombeiros, por favor aguarde informações da Polícia Civil ou entre em contato com órgào responsável ou quem de direito' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Ative a economia de bateria e feche aplicativos secundários. Por favor me passe contatos e nomes das pessoas que estão com você (com DDD) para podermos entrar em contato caso sua bateria acabe. Fique atento ao recebimento de ligações e de mensagens via aplicativo e SMS' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Orientar a enviar coordenadas:

Ponha no Viva Voz e abra o aplicativo do Google Maps (mesmo sem sinal de internet) O círculo azul indicará sua posição. 

Clique e segure sobre este ponto até que um alfinete vermelho seja inserido, a barra superior mostrará uma sequência de números. 

Essas são as coordenadas de onde você está. Repasse exatamente como você vê.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '"Pare, sente-se confortavelmente, como algo, beba água e então procure se reorientar. Escute minhas orientações e tente segui-las."

Se você conhece suficientemente o local (ou possui registros como tracklogs, etc). 

Uma vez que a vítima esteja apenas DESORIENTADA, procure orientá-la de maneira que ela retorne para um ponto conhecido e se reoriente, tornando a ficar em segurança.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );


-- SQL INSERT ORIENTACOES DA NATUREZA NOVA TABELA <--- (EXECUTAR DEPOIS DE TODAS AS QUERYS DESSA NATUREZA)

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante)
Quanto possui de bateria?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Numérico' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Ative a economia de bateria e feche aplicativos secundários. Por favor me passe contatos e nomes das pessoas que estão com você (com DDD) para podermos entrar em contato caso sua bateria acabe. Fique atento ao recebimento de ligações e de mensagens via aplicativo e SMS' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante)
Quanto possui de bateria?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = '' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Ative a economia de bateria e feche aplicativos secundários. Por favor me passe contatos e nomes das pessoas que estão com você (com DDD) para podermos entrar em contato caso sua bateria acabe. Fique atento ao recebimento de ligações e de mensagens via aplicativo e SMS' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Foi verificado os locais de frequencia comum? (residência, casa de parentes e amigos, locais de esporte e lazer, etc)? Hospitais, Unidades de Pronto Atendimento, Unidades Básicas de Saúde?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Por favor, realize contato com parentes, amigos e nos locais de frequência comum para ter certeza que esta pessoa está perdida e deseja ser encontrada. Oriente a buscar vestígios sobre o desaparecimento. Notas, planos, recibos, contatos com amigos.       ' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim

Solicitar contatos e registrar (Nome, Parentesco, Telefone e Endereço)' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim

Solicitar contatos e registrar (Nome, Parentesco, Telefone e Endereço)' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você consegue me mandar sua localização (Whatsapp ou outro aplicativo)?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Orientar a enviar coordenadas:

Ponha no Viva Voz e abra o aplicativo do Google Maps (mesmo sem sinal de internet) O círculo azul indicará sua posição. 

Clique e segure sobre este ponto até que um alfinete vermelho seja inserido, a barra superior mostrará uma sequência de números. 

Essas são as coordenadas de onde você está. Repasse exatamente como você vê.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o último local em que foi visto(a)?
Você consegue me mandar a localização (Whatsapp ou outro aplicativo)?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Descrever
(inserir ponto e/ou coordenadas)' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Orientar a enviar coordenadas:

Ponha no Viva Voz e abra o aplicativo do Google Maps (mesmo sem sinal de internet) O círculo azul indicará sua posição. 

Clique e segure sobre este ponto até que um alfinete vermelho seja inserido, a barra superior mostrará uma sequência de números. 

Essas são as coordenadas de onde você está. Repasse exatamente como você vê.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o último local em que foi visto(a)?
Você consegue me mandar a localização (Whatsapp ou outro aplicativo)?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não sabe' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Orientar a enviar coordenadas:

Ponha no Viva Voz e abra o aplicativo do Google Maps (mesmo sem sinal de internet) O círculo azul indicará sua posição. 

Clique e segure sobre este ponto até que um alfinete vermelho seja inserido, a barra superior mostrará uma sequência de números. 

Essas são as coordenadas de onde você está. Repasse exatamente como você vê.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Descrever
(inserir ponto e/ou coordenadas)' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Descrever
(inserir ponto e/ou coordenadas)' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Descrever
(inserir ponto e/ou coordenadas)' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Orientar a enviar coordenadas:

Ponha no Viva Voz e abra o aplicativo do Google Maps (mesmo sem sinal de internet) O círculo azul indicará sua posição. 

Clique e segure sobre este ponto até que um alfinete vermelho seja inserido, a barra superior mostrará uma sequência de números. 

Essas são as coordenadas de onde você está. Repasse exatamente como você vê.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Mar/Oceano' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima) 
Qual seu último ponto conhecido? Para onde pretendia ir? Há algum ponto de referência destaque que você consegue identificar? Qual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Mar/Oceano' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Ative a economia de bateria e feche aplicativos secundários. Por favor me passe contatos e nomes das pessoas que estão com você (com DDD) para podermos entrar em contato caso sua bateria acabe. Fique atento ao recebimento de ligações e de mensagens via aplicativo e SMS' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Ative a economia de bateria e feche aplicativos secundários. Por favor me passe contatos e nomes das pessoas que estão com você (com DDD) para podermos entrar em contato caso sua bateria acabe. Fique atento ao recebimento de ligações e de mensagens via aplicativo e SMS' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'A pessoa conhece o local?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/Alguém presente conhece o local?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/Alguém presente conhece o local?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '"Pare, sente-se confortavelmente, como algo, beba água e então procure se reorientar. Escute minhas orientações e tente segui-las."

Se você conhece suficientemente o local (ou possui registros como tracklogs, etc). 

Uma vez que a vítima esteja apenas DESORIENTADA, procure orientá-la de maneira que ela retorne para um ponto conhecido e se reoriente, tornando a ficar em segurança.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Vítima próprio Solicitante) Não se locomova, abrigue-se dentro do possível, ative o modo economia de bateria do celular, aguarde socorro e sinalize se possível. Uma equipe deve entrar em contato com você

(Peça contato e nome de outras pessoas que estiverem presentes para mais possibilidades de contato)' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = '(Vítima próprio solicitante/junto da vítima)
Você/A vítima está em condições de se locomover sozinho (se não for óbvio)?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Essa situação não se enquadra no atendimento no Corpo de Bombeiros, por favor aguarde informações da Polícia Civil ou entre em contato com órgào responsável ou quem de direito' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Essa situação não se enquadra no atendimento no Corpo de Bombeiros, por se tratar de pessoa desaparecida, e não de pessoa perdida. Por favor, solicite atendimento da Polícia Civil através da abertura de Boletim de Ocorrência' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Foi aberto Boletim de Ocorrência junto à Polícia Civil?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B16 - PESSOA PERDIDA') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Essa situação não se enquadra no atendimento no Corpo de Bombeiros, por favor aguarde informações da Polícia Civil ou entre em contato com órgào responsável ou quem de direito' AND arv_card.descricao = 'B16 - PESSOA PERDIDA' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );


-- SQL UPDATE ALTERNATIVAS DAS ORIENTAÇÔES DESSA NATUREZA QUE CHAMA OUTRA ORIENTAÇÃO DESSA NATUREZA TMB

