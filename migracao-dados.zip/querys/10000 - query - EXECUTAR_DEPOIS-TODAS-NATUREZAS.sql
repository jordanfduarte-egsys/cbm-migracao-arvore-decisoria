

-- T2 - ACIDENTE DE TRANSITO



-- SQL UPDATE PROXIMO PASSO OUTRA NATUREZA DIFERENTE: T2 - ACIDENTE DE TRANSITO <--- (EXECUTAR DEPOIS DE INSERIR TODAS AS NATUREZAS)

UPDATE arv_perg_alt SET id_prox_arv_perg = (
                    select arv_perg1.id from arv_perg arv_perg1
                    inner join classificacao_atendimento classificacao_atendimento1 on
                        classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                    where classificacao_atendimento1.descricao like 'OPS 7%' and arv_perg1.excluido  = 0 
                        limit 1 offset 0
                ) WHERE id_arv_perg = (
                    SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                    WHERE arv_perg.descricao = 'Veículo 2 envolvido?' 
                    AND lower(classificacao_atendimento.descricao) = lower('T2 - ACIDENTE DE TRANSITO') AND arv_perg.excluido = 0 LIMIT 1
                ) AND arv_perg_alt.descricao = 'Evadiu-se' AND arv_perg_alt.excluido = 0

UPDATE arv_perg_alt SET id_prox_arv_perg = (
                    select arv_perg1.id from arv_perg arv_perg1
                    inner join classificacao_atendimento classificacao_atendimento1 on
                        classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                    where classificacao_atendimento1.descricao like 'OPS6%' and arv_perg1.excluido  = 0 
                        limit 1 offset 0
                ) WHERE id_arv_perg = (
                    SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                    WHERE arv_perg.descricao = 'Existem Vítimas?' 
                    AND lower(classificacao_atendimento.descricao) = lower('T2 - ACIDENTE DE TRANSITO') AND arv_perg.excluido = 0 LIMIT 1
                ) AND arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0


-- B13 - INCIDENTE COM EMBARCAÇÃO



-- SQL UPDATE PROXIMO PASSO OUTRA NATUREZA DIFERENTE: B13 - INCIDENTE COM EMBARCAÇÃO <--- (EXECUTAR DEPOIS DE INSERIR TODAS AS NATUREZAS)

UPDATE arv_perg_alt SET id_prox_arv_perg = (
                    select arv_perg1.id from arv_perg arv_perg1
                    inner join classificacao_atendimento classificacao_atendimento1 on
                        classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                    where classificacao_atendimento1.descricao like 'OPS6%' and arv_perg1.excluido  = 0 
                        limit 1 offset 0
                ) WHERE id_arv_perg = (
                    SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                    WHERE arv_perg.descricao = 'Qual a inscrição  da embarcação?' 
                    AND lower(classificacao_atendimento.descricao) = lower('B13 - INCIDENTE COM EMBARCAÇÃO') AND arv_perg.excluido = 0 LIMIT 1
                ) AND arv_perg_alt.descricao = 'Descrever' AND arv_perg_alt.excluido = 0


-- COMPLEMENTAR - PESSOA



-- SQL UPDATE PROXIMO PASSO OUTRA NATUREZA DIFERENTE: COMPLEMENTAR - PESSOA <--- (EXECUTAR DEPOIS DE INSERIR TODAS AS NATUREZAS)

UPDATE arv_perg_alt SET id_prox_arv_perg = (
                    select arv_perg1.id from arv_perg arv_perg1
                    inner join classificacao_atendimento classificacao_atendimento1 on
                        classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                    where classificacao_atendimento1.descricao like 'RETORNAR%' and arv_perg1.excluido  = 0 
                        limit 1 offset 0
                ) WHERE id_arv_perg = (
                    SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                    WHERE arv_perg.descricao = 'Alguma informação adicional? (cicatriz, tatuagem, etc)' 
                    AND lower(classificacao_atendimento.descricao) = lower('COMPLEMENTAR - PESSOA') AND arv_perg.excluido = 0 LIMIT 1
                ) AND arv_perg_alt.descricao = 'Descrever' AND arv_perg_alt.excluido = 0
