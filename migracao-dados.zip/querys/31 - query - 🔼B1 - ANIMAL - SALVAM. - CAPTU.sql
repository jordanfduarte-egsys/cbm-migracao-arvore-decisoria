--SQL CLASSIFICACAO -- ATENÇÃO VER SE JA NAO EXISTE (EXECUTAR ANTES DE TD DESSA NATUREZA)<--------------

SELECT * FROM classificacao_atendimento WHERE descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND classificacao_atendimento.excluido = 0 ;
INSERT INTO public.classificacao_atendimento (descricao, id_tipo_atendimento, id_nivel_atendimento, id_categoria) VALUES('🔼B1 - ANIMAL - SALVAM. - CAPTU', 354, 3, 24);

                INSERT INTO public.classificacao_atend_agencia (id_classificacao_atendimento, id_agencia) VALUES ((SELECT classificacao_atendimento1.id FROM classificacao_atendimento classificacao_atendimento1 WHERE classificacao_atendimento1.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND classificacao_atendimento1.id_nivel_atendimento = 3  AND classificacao_atendimento1.excluido = 0), 3);


-- SQL CARD

INSERT INTO arv_card (id_classificacao_atendimento, descricao) VALUES (
                (SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU'  AND classificacao_atendimento.excluido = 0 LIMIT 1),
                '🔼B1 - ANIMAL - SALVAM. - CAPTU'
            );


-- SQL de PERGUNTAS

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Alguém foi mordido pelo animal?', 0, 1);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'O que aconteceu exatamente?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'É um animal doméstico ou selvagem?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual a espécie/raça do animal?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Apresenta agressividade e risco ao público?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Quem irá se responsabilizar pelo animal após o resgate?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'É a primeira vez que liga para o Corpo de Bombeiros?', 0, 0);


-- SQL de ALTERNATIVAS

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Alguém foi mordido pelo animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Alguém foi mordido pelo animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O que aconteceu exatamente?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O que aconteceu exatamente?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Fugiu', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O que aconteceu exatamente?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Rodovia (descrever situação)', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O que aconteceu exatamente?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Preso', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O que aconteceu exatamente?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Entalado', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O que aconteceu exatamente?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Ilhado (sem risco)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O que aconteceu exatamente?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Animal solto', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O que aconteceu exatamente?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Local de dificíl acesso', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Doméstico', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Selvagem', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Cachorro', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Gato', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Pássaro', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Cavalo', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Gado', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outro', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Sim', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Solicitante', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Proprietário', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outro Órgão', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outros', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 1, 'Sim', 1, 1, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 1, 'Não', 1, 1, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));


-- SQL de AGE. ENVOLVIDO

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('PRF') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Rodovia (descrever situação)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('PRE') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Rodovia (descrever situação)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Concessionária') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Rodovia (descrever situação)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Polícia de Trânsito') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Rodovia (descrever situação)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Preso' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Entalado' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Local de dificíl acesso' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Prefeitura') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Doméstico' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Força Verde') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Selvagem' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'É um animal doméstico ou selvagem?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('Prefeitura') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Gato' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_ext_envol (
                        id_tipo_apoio,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT cbm_tipo_apoio_externo.id FROM cbm_tipo_apoio_externo WHERE UPPER(cbm_tipo_apoio_externo.descricao) = UPPER('ONGS') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Gato' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual a espécie/raça do animal?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );


-- SQL ORIENTACOES NATUREZA

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 LIMIT 1),
                        'Se for um ferimento leve, lave o ferimento com água corrente e sabão. Buscar um posto de saúde para tratamentos complementares.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 LIMIT 1),
                        '(Animal atacando) Se for seguro, jogue água no animal ou afaste-o com objeto longo (vassoura), mas não bata.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 LIMIT 1),
                        '(perdido, Ilhado ou difícil acesso) Informe ao solicitante que animais possuem instinto apurado e sabem sair destas situações. Peça para aguardar 24h e após realizar nova solicitação.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 LIMIT 1),
                        'Não bata no animal. Peça para se afastarem do animal para que ninguém mais se machuque.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 LIMIT 1),
                        'O Corpo de Bombeiros não irá se responsabilizar pelo animal resgatado. A responsabilidade pelo animal é do seu proprietário, que responde civil e criminalmente pelos danos causados por ele. '
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 LIMIT 1),
                        'Seu chamado foi cadastrado. Qualquer alteração no local, retorne a ligação ao 193.'
                    );


-- SQL ALTERNATIVA ORIENTACAO

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Se for um ferimento leve, lave o ferimento com água corrente e sabão. Buscar um posto de saúde para tratamentos complementares.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Animal atacando) Se for seguro, jogue água no animal ou afaste-o com objeto longo (vassoura), mas não bata.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(perdido, Ilhado ou difícil acesso) Informe ao solicitante que animais possuem instinto apurado e sabem sair destas situações. Peça para aguardar 24h e após realizar nova solicitação.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Não bata no animal. Peça para se afastarem do animal para que ninguém mais se machuque.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'O Corpo de Bombeiros não irá se responsabilizar pelo animal resgatado. A responsabilidade pelo animal é do seu proprietário, que responde civil e criminalmente pelos danos causados por ele. ' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Seu chamado foi cadastrado. Qualquer alteração no local, retorne a ligação ao 193.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );


-- SQL INSERT ORIENTACOES DA NATUREZA NOVA TABELA <--- (EXECUTAR DEPOIS DE TODAS AS QUERYS DESSA NATUREZA)

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Alguém foi mordido pelo animal?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Se for um ferimento leve, lave o ferimento com água corrente e sabão. Buscar um posto de saúde para tratamentos complementares.' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, id_outra_arv_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Alguém foi mordido pelo animal?' 
                                AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                        
                        ),
                        415, -- padrão
                        (
                            select arv_perg1.id from arv_perg arv_perg1
                            inner join classificacao_atendimento classificacao_atendimento1 on
                                classificacao_atendimento1.id = arv_perg1.id_classificacao_atendimento
                            where classificacao_atendimento1.descricao like 'T5%' and arv_perg1.excluido  = 0 
                            limit 1 offset 0
                        ),
                        1
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Fugiu' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração no local, retorne a ligação ao 193.' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Ilhado (sem risco)' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(perdido, Ilhado ou difícil acesso) Informe ao solicitante que animais possuem instinto apurado e sabem sair destas situações. Peça para aguardar 24h e após realizar nova solicitação.' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'O que aconteceu exatamente?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Ilhado (sem risco)' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'O Corpo de Bombeiros não irá se responsabilizar pelo animal resgatado. A responsabilidade pelo animal é do seu proprietário, que responde civil e criminalmente pelos danos causados por ele. ' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Animal atacando) Se for seguro, jogue água no animal ou afaste-o com objeto longo (vassoura), mas não bata.' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'O Corpo de Bombeiros não irá se responsabilizar pelo animal resgatado. A responsabilidade pelo animal é do seu proprietário, que responde civil e criminalmente pelos danos causados por ele. ' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração no local, retorne a ligação ao 193.' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não bata no animal. Peça para se afastarem do animal para que ninguém mais se machuque.' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Apresenta agressividade e risco ao público?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'O Corpo de Bombeiros não irá se responsabilizar pelo animal resgatado. A responsabilidade pelo animal é do seu proprietário, que responde civil e criminalmente pelos danos causados por ele. ' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Quem irá se responsabilizar pelo animal após o resgate?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não sabe' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'O Corpo de Bombeiros não irá se responsabilizar pelo animal resgatado. A responsabilidade pelo animal é do seu proprietário, que responde civil e criminalmente pelos danos causados por ele. ' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração no local, retorne a ligação ao 193.' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'É a primeira vez que liga para o Corpo de Bombeiros?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('🔼B1 - ANIMAL - SALVAM. - CAPTU') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração no local, retorne a ligação ao 193.' AND arv_card.descricao = '🔼B1 - ANIMAL - SALVAM. - CAPTU' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );


-- SQL UPDATE ALTERNATIVAS DAS ORIENTAÇÔES DESSA NATUREZA QUE CHAMA OUTRA ORIENTAÇÃO DESSA NATUREZA TMB

