--SQL CLASSIFICACAO -- ATENÇÃO VER SE JA NAO EXISTE (EXECUTAR ANTES DE TD DESSA NATUREZA)<--------------

SELECT * FROM classificacao_atendimento WHERE descricao = 'C4 - DIABETES' AND classificacao_atendimento.excluido = 0 ;
INSERT INTO public.classificacao_atendimento (descricao, id_tipo_atendimento, id_nivel_atendimento, id_categoria) VALUES('C4 - DIABETES', 352, 3, 24);

                INSERT INTO public.classificacao_atend_agencia (id_classificacao_atendimento, id_agencia) VALUES ((SELECT classificacao_atendimento1.id FROM classificacao_atendimento classificacao_atendimento1 WHERE classificacao_atendimento1.descricao = 'C4 - DIABETES' AND classificacao_atendimento1.id_nivel_atendimento = 3  AND classificacao_atendimento1.excluido = 0), 3);


-- SQL CARD

INSERT INTO arv_card (id_classificacao_atendimento, descricao) VALUES (
                (SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE descricao = 'C4 - DIABETES'  AND classificacao_atendimento.excluido = 0 LIMIT 1),
                'C4 - DIABETES'
            );


-- SQL de PERGUNTAS

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A pessoa está alerta? Conversa?', 0, 1);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Aproxime-se da pessoa e veja se ela reage a um estímulo', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'A pessoa respira normalmente?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Observe e descreva a respiração ', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'O paciente usa insulina?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'O paciente alimentou-se recentemente?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Quando foi a última vez que tomou a medicação?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'O paciente possui um medidor de glicose?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual a medida atual?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'O paciente está suando frio?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Teve algum episódio de convulsão?', 0, 0);


-- SQL de ALTERNATIVAS

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa está alerta? Conversa?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa está alerta? Conversa?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Aproxime-se da pessoa e veja se ela reage a um estímulo' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Não', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa está alerta? Conversa?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Aproxime-se da pessoa e veja se ela reage a um estímulo' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Aproxime-se da pessoa e veja se ela reage a um estímulo' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Reage a  estímulo (abre os olhos)', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Aproxime-se da pessoa e veja se ela reage a um estímulo' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Não reage a estímulo', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Aproxime-se da pessoa e veja se ela reage a um estímulo' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Não', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'A pessoa respira normalmente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Não está respirando', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Ausência de movimentos no tórax', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Respiração Agônica (gasping)', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Pausa respiratória (apneia)', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Cianose generalizada (roxa)', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Respiração ruidosa', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Falta de ar', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Observe e descreva a respiração ' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Respiração pouco ruidosa', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Quando foi a última vez que tomou a medicação?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Sim', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente alimentou-se recentemente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Não', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente usa insulina?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente alimentou-se recentemente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente alimentou-se recentemente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Sim', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente alimentou-se recentemente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente alimentou-se recentemente?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quando foi a última vez que tomou a medicação?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente possui um medidor de glicose?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Númerico em minutos', 1, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'INT' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Quando foi a última vez que tomou a medicação?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente possui um medidor de glicose?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente possui um medidor de glicose?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a medida atual?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente possui um medidor de glicose?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a medida atual?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Numérico', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'INT' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a medida atual?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Abaixo de 70', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente está suando frio?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sim', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'O paciente está suando frio?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente está suando frio?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Sim', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'O paciente está suando frio?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Não', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Sim', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 1, 'Não', 1, 0, 0, NULL);


-- SQL de AGE. ENVOLVIDO

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa está alerta? Conversa?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa está alerta? Conversa?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não reage a estímulo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Aproxime-se da pessoa e veja se ela reage a um estímulo' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não reage a estímulo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Aproxime-se da pessoa e veja se ela reage a um estímulo' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa respira normalmente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa respira normalmente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não está respirando' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa respira normalmente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não está respirando' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa respira normalmente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Ausência de movimentos no tórax' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Ausência de movimentos no tórax' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Respiração Agônica (gasping)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Respiração Agônica (gasping)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Pausa respiratória (apneia)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Cianose generalizada (roxa)' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Respiração ruidosa' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Falta de ar' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Respiração pouco ruidosa' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente usa insulina?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente usa insulina?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente usa insulina?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente alimentou-se recentemente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Númerico em minutos' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Quando foi a última vez que tomou a medicação?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Númerico em minutos' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Quando foi a última vez que tomou a medicação?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Abaixo de 70' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual a medida atual?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Abaixo de 70' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual a medida atual?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente apresenta comportamento diferente? confuso, tontura ou fraco?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente está suando frio?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente está suando frio?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'O paciente está suando frio?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SAV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Sim' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('SBV') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Não' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );


-- SQL ORIENTACOES NATUREZA

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 LIMIT 1),
                        '(Vítima não alerta) VÁ PARA O CARTÃO DE RCP'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 LIMIT 1),
                        'Não dê nada para beber ou comer, a não ser que ela possa fazer sozinha.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 LIMIT 1),
                        '(Nível abaixo de 70 mg/dl) Se ela puder beber ou comer sozinha, dê a ela suco com 2 a 3 colheres de açúcar.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 LIMIT 1),
                        'Deixe a pessoa na posição mais confortável.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 LIMIT 1),
                        'Decúbito lateral no caso de Vômito'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 LIMIT 1),
                        'Repasse a equipe de emergência os medicamentos.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 LIMIT 1),
                        'Verificar e garantir o ABC da vítima.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 LIMIT 1),
                        'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.'
                    );


-- SQL ALTERNATIVA ORIENTACAO

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Vítima não alerta) VÁ PARA O CARTÃO DE RCP' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Não dê nada para beber ou comer, a não ser que ela possa fazer sozinha.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = '(Nível abaixo de 70 mg/dl) Se ela puder beber ou comer sozinha, dê a ela suco com 2 a 3 colheres de açúcar.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Deixe a pessoa na posição mais confortável.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Decúbito lateral no caso de Vômito' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Repasse a equipe de emergência os medicamentos.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Verificar e garantir o ABC da vítima.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'C4 - DIABETES' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );


-- SQL INSERT ORIENTACOES DA NATUREZA NOVA TABELA <--- (EXECUTAR DEPOIS DE TODAS AS QUERYS DESSA NATUREZA)

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'A pessoa respira normalmente?' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Não está respirando' AND arv_perg_alt.excluido = 0
                        
                        ),
                        (
                            SELECT arv_card_perg.id FROM arv_card_perg 
                        INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                        WHERE UPPER(arv_card.descricao) = UPPER('RCP') and arv_card_perg.is_pergunta_raiz = 1 and arv_card_perg.excluido = 0 limit 1
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Ausência de movimentos no tórax' AND arv_perg_alt.excluido = 0
                        
                        ),
                        (
                            SELECT arv_card_perg.id FROM arv_card_perg 
                        INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                        WHERE UPPER(arv_card.descricao) = UPPER('RCP') and arv_card_perg.is_pergunta_raiz = 1 and arv_card_perg.excluido = 0 limit 1
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Respiração Agônica (gasping)' AND arv_perg_alt.excluido = 0
                        
                        ),
                        (
                            SELECT arv_card_perg.id FROM arv_card_perg 
                        INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                        WHERE UPPER(arv_card.descricao) = UPPER('RCP') and arv_card_perg.is_pergunta_raiz = 1 and arv_card_perg.excluido = 0 limit 1
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                        (
                            SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Observe e descreva a respiração ' 
                                AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                            ) AND descricao = 'Respiração pouco ruidosa' AND arv_perg_alt.excluido = 0
                        
                        ),
                        (
                            SELECT arv_card_perg.id FROM arv_card_perg 
                        INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                        WHERE UPPER(arv_card.descricao) = UPPER('RCP') and arv_card_perg.is_pergunta_raiz = 1 and arv_card_perg.excluido = 0 limit 1
                        ),
                        0
                    );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual a medida atual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Abaixo de 70' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = '(Nível abaixo de 70 mg/dl) Se ela puder beber ou comer sozinha, dê a ela suco com 2 a 3 colheres de açúcar.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual a medida atual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Abaixo de 70' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Deixe a pessoa na posição mais confortável.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual a medida atual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Abaixo de 70' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Decúbito lateral no caso de Vômito' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual a medida atual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Abaixo de 70' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Repasse a equipe de emergência os medicamentos.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            3
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual a medida atual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Abaixo de 70' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Verificar e garantir o ABC da vítima.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            4
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual a medida atual?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Abaixo de 70' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            5
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não dê nada para beber ou comer, a não ser que ela possa fazer sozinha.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Deixe a pessoa na posição mais confortável.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Decúbito lateral no caso de Vômito' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Repasse a equipe de emergência os medicamentos.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            3
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Verificar e garantir o ABC da vítima.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            4
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            5
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não dê nada para beber ou comer, a não ser que ela possa fazer sozinha.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Deixe a pessoa na posição mais confortável.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Decúbito lateral no caso de Vômito' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Repasse a equipe de emergência os medicamentos.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            3
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Verificar e garantir o ABC da vítima.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            4
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Teve algum episódio de convulsão?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('C4 - DIABETES') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'C4 - DIABETES' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            5
                        );


-- SQL UPDATE ALTERNATIVAS DAS ORIENTAÇÔES DESSA NATUREZA QUE CHAMA OUTRA ORIENTAÇÃO DESSA NATUREZA TMB

