--SQL CLASSIFICACAO -- ATENÇÃO VER SE JA NAO EXISTE (EXECUTAR ANTES DE TD DESSA NATUREZA)<--------------

SELECT * FROM classificacao_atendimento WHERE descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND classificacao_atendimento.excluido = 0 ;
INSERT INTO public.classificacao_atendimento (descricao, id_tipo_atendimento, id_nivel_atendimento, id_categoria) VALUES('B22 - VAZAMENTO GAS - GLP-GN', 354, 3, 24);

                INSERT INTO public.classificacao_atend_agencia (id_classificacao_atendimento, id_agencia) VALUES ((SELECT classificacao_atendimento1.id FROM classificacao_atendimento classificacao_atendimento1 WHERE classificacao_atendimento1.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND classificacao_atendimento1.id_nivel_atendimento = 3  AND classificacao_atendimento1.excluido = 0), 3);


-- SQL CARD

INSERT INTO arv_card (id_classificacao_atendimento, descricao) VALUES (
                (SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE descricao = 'B22 - VAZAMENTO GAS - GLP-GN'  AND classificacao_atendimento.excluido = 0 LIMIT 1),
                'B22 - VAZAMENTO GAS - GLP-GN'
            );


-- SQL de PERGUNTAS

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual o tipo de vazamento?', 0, 1);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Em que ambiente é o odor ou de onde o gás está vazando?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual a quantidade de gás estocada? Capacidade dos Botijões?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Qual a quantidade de botijões?', 0, 0);

INSERT INTO arv_perg (id_classificacao_atendimento, descricao, excluido, is_pergunta_raiz) VALUES ((SELECT classificacao_atendimento.id FROM classificacao_atendimento WHERE lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN')  AND classificacao_atendimento.excluido = 0 LIMIT 1), 'Existe alguém em perigo?', 0, 0);


-- SQL de ALTERNATIVAS

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Odor', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Vazamento visível', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Vazamento com fogo', 1, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Outro', 1, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Externo', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Central de Gás', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'Veículo', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Linha de GNV', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Interno', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Em que ambiente é o odor ou de onde o gás está vazando?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outro', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Botijão P-13', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 1, 'Botijão P-45', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 2, 'P-90 ou mais', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, 3, 'Linha de GNV', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a quantidade de gás estocada? Capacidade dos Botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Qual a quantidade de botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Outro', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'ALPHA' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Qual a quantidade de botijões?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    (SELECT arv_perg.id FROM arv_perg 
                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id
                    WHERE arv_perg.descricao = 'Existe alguém em perigo?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                ),
                    NULL, NULL, NULL, 'Numérico', 0, 0, 0, (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'INT' AND arv_mascara.excluido = 0 LIMIT 1));

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe alguém em perigo?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, 3, 'Sim', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe alguém em perigo?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Não', 0, 0, 0, NULL);

INSERT INTO arv_perg_alt (
                    id_arv_perg,
                    id_prox_arv_perg,
                    id_arv_card_pergunta,
                    id_arv_card,
                    id_nivel_atendimento,
                    descricao,
                    is_gerar_ocorrencia,
                    is_enc_atendimento,
                    excluido,
                    id_arv_mascara
                ) VALUES (
                    (SELECT arv_perg.id FROM arv_perg INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id WHERE arv_perg.descricao = 'Existe alguém em perigo?' AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1),
                    NULL,
                    NULL, NULL, NULL, 'Não sabe', 0, 0, 0, NULL);


-- SQL de AGE. ENVOLVIDO

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Odor' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Vazamento visível' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Vazamento com fogo' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );

INSERT INTO arv_perg_alt_ag_envol (
                        id_tipo_guarnicao,
                        id_perg_alt,
                        excluido
                        ) VALUES (
                            (SELECT tipo_guarnicao.id FROM tipo_guarnicao WHERE UPPER(tipo_guarnicao.descricao) = UPPER('ABTR') LIMIT 1),
                            (SELECT arv_perg_alt.id FROM arv_perg_alt WHERE arv_perg_alt.descricao = 'Outro' AND arv_perg_alt.excluido = 0 AND arv_perg_alt.id_arv_perg = (
                                SELECT arv_perg.id FROM arv_perg 
                                INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                            ) LIMIT 1),
                            0
                        );


-- SQL ORIENTACOES NATUREZA

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 LIMIT 1),
                        'Retire as pessoas do ambiente e permaneça em ambiente com ar fresco.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 LIMIT 1),
                        'Feche o registro de gás geral ou do andar.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 LIMIT 1),
                        'Não utilize, nem ligue ou desligue equipamento elétrico.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 LIMIT 1),
                        'Abra portas e janelas para arejar o ambiente.'
                    );

INSERT INTO arv_card_perg (id_arv_card, descricao) VALUES (
                        (SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 LIMIT 1),
                        'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.'
                    );


-- SQL ALTERNATIVA ORIENTACAO

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Retire as pessoas do ambiente e permaneça em ambiente com ar fresco.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Feche o registro de gás geral ou do andar.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Não utilize, nem ligue ou desligue equipamento elétrico.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Abra portas e janelas para arejar o ambiente.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );

INSERT INTO arv_card_perg_alt (
                id_arv_card_perg,
                id_prox_arv_card_perg,
                descricao,
                id_arv_mascara)
                VALUES(
                    (
                        SELECT arv_card_perg.id FROM arv_card_perg                     
                        WHERE descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' 
                        AND arv_card_perg.id_arv_card = (
                            SELECT arv_card.id FROM arv_card WHERE arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card.excluido = 0 
                        )
                        AND arv_card_perg.excluido = 0 
                        LIMIT 1
                    ),
                    NULL,
                    'Orientado',
                    (SELECT arv_mascara.id FROM arv_mascara WHERE chave = 'CHECKED' AND arv_mascara.excluido = 0 LIMIT 1)
                );


-- SQL INSERT ORIENTACOES DA NATUREZA NOVA TABELA <--- (EXECUTAR DEPOIS DE TODAS AS QUERYS DESSA NATUREZA)

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Odor' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Retire as pessoas do ambiente e permaneça em ambiente com ar fresco.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Odor' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Feche o registro de gás geral ou do andar.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Odor' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não utilize, nem ligue ou desligue equipamento elétrico.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Odor' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Abra portas e janelas para arejar o ambiente.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            3
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Vazamento visível' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Retire as pessoas do ambiente e permaneça em ambiente com ar fresco.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Vazamento visível' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Feche o registro de gás geral ou do andar.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Vazamento visível' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não utilize, nem ligue ou desligue equipamento elétrico.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Vazamento visível' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Abra portas e janelas para arejar o ambiente.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            3
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Vazamento com fogo' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Retire as pessoas do ambiente e permaneça em ambiente com ar fresco.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Vazamento com fogo' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Feche o registro de gás geral ou do andar.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Vazamento com fogo' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não utilize, nem ligue ou desligue equipamento elétrico.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Vazamento com fogo' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Abra portas e janelas para arejar o ambiente.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            3
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Outro' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Retire as pessoas do ambiente e permaneça em ambiente com ar fresco.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Outro' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Feche o registro de gás geral ou do andar.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            1
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Outro' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Não utilize, nem ligue ou desligue equipamento elétrico.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            2
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Qual o tipo de vazamento?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Outro' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Abra portas e janelas para arejar o ambiente.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            3
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existe alguém em perigo?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Sim' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existe alguém em perigo?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );

INSERT INTO arv_perg_alt_arv_card_perg (id_arv_perg_alt, id_arv_card_perg, ordem) VALUES (
                            (
                                SELECT arv_perg_alt.id FROM arv_perg_alt WHERE id_arv_perg = (
                                    SELECT arv_perg.id FROM arv_perg 
                                    INNER JOIN classificacao_atendimento ON arv_perg.id_classificacao_atendimento = classificacao_atendimento.id 
                                    WHERE arv_perg.descricao = 'Existe alguém em perigo?' 
                                    AND lower(classificacao_atendimento.descricao) = lower('B22 - VAZAMENTO GAS - GLP-GN') AND arv_perg.excluido = 0 LIMIT 1
                                ) AND descricao = 'Não sabe' AND arv_perg_alt.excluido = 0
                            
                            ),
                            (
                                SELECT arv_card_perg.id FROM arv_card_perg 
                                INNER JOIN arv_card ON arv_card_perg.id_arv_card = arv_card.id
                                WHERE arv_card_perg.descricao = 'Seu chamado foi cadastrado. Qualquer alteração da(s) vítima(s) ou no local, retorne a ligação ao 193.' AND arv_card.descricao = 'B22 - VAZAMENTO GAS - GLP-GN' AND arv_card_perg.excluido = 0 LIMIT 1
                            ),
                            0
                        );


-- SQL UPDATE ALTERNATIVAS DAS ORIENTAÇÔES DESSA NATUREZA QUE CHAMA OUTRA ORIENTAÇÃO DESSA NATUREZA TMB

