<?php
require "./vendor/autoload.php";
require "./function.php";
set_time_limit(-1);

echo "<pre>";

$nomeArquivo = "arvoreFINAL.csv";
$file = "./{$nomeArquivo}";

echo "Iniciando processo<br><br>";

echo "Removendo arquivo: {$nomeArquivo}<br><br>";
unlink("{$nomeArquivo}");

echo "Criando novo arquivo: {$nomeArquivo}<br><br>";
exec("xlsx2csv arvore.xlsx --all > {$nomeArquivo}", $a, $b);


$dir = "./querys";
$di = new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS);
$ri = new RecursiveIteratorIterator($di, RecursiveIteratorIterator::CHILD_FIRST);

foreach ( $ri as $file ) {
    $file->isDir() ?  rmdir($file) : unlink($file);
}
// https://www.geeksforgeeks.org/methods-to-convert-xlsx-format-files-to-csv-on-linux-cli/#:~:text=Gnumeric%20Spreadsheet%20Program&text=To%20install%20Gnumeric%20in%20Linux,Gnumeric%20repository%20via%20Linux%20terminal.&text=Now%20to%20convert%20xlsx%20format,Gnumeric%20to%20convert%20the%20file.&text=To%20view%20the%20contents%20of,to%20check%20the%20csv%20file.
// $ xlsx2csv SampleData.xlsx --all > Output.csv

function printAll($all) {
    $sql = [];
    foreach ($all as $row) {
        $sql[] = trim($row) . "\n";
    }

    return implode("\n", $sql);
}
$sqlAgenciaEnvolvidaCadastroGuanicoes = [];
try {
    $reader = \Ark4ne\XlReader\Factory::createReader($file);    
    $reader->load();
        
    $aParams = [];
    $natureza = "";
    $naturezaOld = "";
    $initParam = false;
    echo "Iniciando processo dos scripts<br><br>";
    $processados = 0;
    $countUpdatesNaturezas = 0;
    foreach ($reader->read() as $row) {
        if (preg_match("/------/", $row['A'])) {
            $natureza = preg_replace("/-------- \d -/", "", $row['A']);
            $natureza = preg_replace("/-------- \d\d -/", "", $natureza);
            $natureza = str_replace("COMPL", "COMPLEMENTAR", $natureza);
            $natureza = trim($natureza);

            if (in_array($natureza, ['INICIAL', 'INGLES'])) {
                $aParams = [];
                continue;
            }
            $initParam = true;
        }

        if (preg_match("/(------).*/", $row['A']) && !empty($aParams)) {
            $result = getSql($aParams, $naturezaOld);
            $sqlsPerguntas = $result['sqlsPerguntas'];
        
            $sqlAlternativas = $result['sqlAlternativas'];
            $sqlNatureza = $result['sqlNatureza'];
            $sqlAgenciaEnvolvida = $result['sqlAgenciaEnvolvida'];
            $sqlCard = $result['sqlCard'];
            $sqlProximoPassoOutraNatureza = $result['sqlProximoPassoOutraNatureza'];
            $sqlsOrientacoesNatureza = $result['sqlsOrientacoesNatureza'];
            $sqlsOrientacoesNaturezaAlternativa = $result['sqlsOrientacoesNaturezaAlternativa'];
            $sqlUpdateOrientacaoNatureza = $result['sqlUpdateOrientacaoNatureza'];
            $sqlAgenciaEnvolvidaCadastroGuanicoes2 = $result['sqlAgenciaEnvolvidaCadastroGuanicoes'];
            $sqlUpdateAlternativaCardNatureza = $result['sqlUpdateAlternativaCardNatureza'];
            $sqlAgenciaEnvolvidaCadastroGuanicoes = array_merge($sqlAgenciaEnvolvidaCadastroGuanicoes, $sqlAgenciaEnvolvidaCadastroGuanicoes2);
            $sqlFinal = "";
            $sqlFinal .= "--SQL CLASSIFICACAO -- ATENÇÃO VER SE JA NAO EXISTE (EXECUTAR ANTES DE TD DESSA NATUREZA)<--------------\n\n";            
            $sqlFinal .=  printAll($sqlNatureza);

            $sqlFinal .=  "\n\n-- SQL CARD\n\n";
            $sqlFinal .=  printAll($sqlCard);

            $sqlFinal .=  "\n\n-- SQL de PERGUNTAS\n\n";
            $sqlFinal .=  printAll($sqlsPerguntas);
            
            $sqlFinal .=  "\n\n-- SQL de ALTERNATIVAS\n\n";
            $sqlFinal .=  printAll($sqlAlternativas);
            
            $sqlFinal .=  "\n\n-- SQL de AGE. ENVOLVIDO\n\n";
            $sqlFinal .=  printAll($sqlAgenciaEnvolvida);
            
            $sqlFinal .=  "\n\n-- SQL ORIENTACOES NATUREZA\n\n";
            $sqlFinal .=  printAll($sqlsOrientacoesNatureza);
            
            $sqlFinal .=  "\n\n-- SQL ALTERNATIVA ORIENTACAO\n\n";
            $sqlFinal .=  printAll($sqlsOrientacoesNaturezaAlternativa);
            
            $sqlFinal .=  "\n\n-- SQL INSERT ORIENTACOES DA NATUREZA NOVA TABELA <--- (EXECUTAR DEPOIS DE TODAS AS QUERYS DESSA NATUREZA)\n\n";
            $sqlFinal .=  printAll($sqlUpdateOrientacaoNatureza);

            $sqlFinal .= "\n\n-- SQL UPDATE ALTERNATIVAS DAS ORIENTAÇÔES DESSA NATUREZA QUE CHAMA OUTRA ORIENTAÇÃO DESSA NATUREZA TMB\n\n";
            $sqlFinal .=  printAll($sqlUpdateAlternativaCardNatureza);            

            // $sqlFinal .=  "\n\n-- SQL UPDATE PROXIMO PASSO OUTRA NATUREZA DIFERENTE <--- (EXECUTAR DEPOIS DE INSERIR TODAS AS NATUREZAS)\n\n";
            // $sqlFinal .=  printAll($sqlProximoPassoOutraNatureza);            
            if ($sqlProximoPassoOutraNatureza) {
                $countUpdatesNaturezas += count($sqlProximoPassoOutraNatureza);
                $sqlFinal1 = "\n\n-- " . $naturezaOld . "\n\n";
                $sqlFinal1 .=  "\n\n-- SQL UPDATE PROXIMO PASSO OUTRA NATUREZA DIFERENTE: {$naturezaOld} <--- (EXECUTAR DEPOIS DE INSERIR TODAS AS NATUREZAS)\n\n";
                $sqlFinal1 .=  printAll($sqlProximoPassoOutraNatureza);
                error_log($sqlFinal1, 3, "./querys/10000 - query - EXECUTAR_DEPOIS-TODAS-NATUREZAS.sql");
            }

            $processadosItem = $processados + 1;
            error_log($sqlFinal, 3, "./querys/{$processadosItem} - query - {$naturezaOld}.sql");
            if (!isset($_GET['OUTRO'])) {
                echo "<div style='color:green;'>Finalizado processo na natureza: <b>" . $naturezaOld . "</b></div> <br><br>";
            }

            $aParams = [];
            $processados++;
        } elseif (!preg_match("/(------).*/", $row['A'])) {
            $naturezaOld = $natureza;
            if ($initParam) {
                $aParam = [];
                foreach ($row as $column) {
                    $aParam[] = empty($column) && $column != 0 ? "" : $column;
                }
                $aParams[] = $aParam;
            }
        }
    }

    if ($sqlAgenciaEnvolvidaCadastroGuanicoes) {
        $sqlFinal2 = "\n\n-- " . $naturezaOld . "\n\n";
        $sqlFinal2 .=  "\n\n-- SQL INSERT AGENCIA ENVOLVIDA: {$naturezaOld} <--- (EXECUTAR ANTES DE TUDO)\n\n";
        $sqlFinal2 .=  printAll($sqlAgenciaEnvolvidaCadastroGuanicoes);
        error_log($sqlFinal2, 3, "./querys/00 - query - EXECUTAR_ANTES.sql");
    }
    
    echo "Processados: " . $processados . "<br><br>";
    echo "Processados naturezas updates: " . $countUpdatesNaturezas . "<br><br>";
    echo "FIM<br><br>";
} catch (Exception $e) {
    var_dump($e);
}